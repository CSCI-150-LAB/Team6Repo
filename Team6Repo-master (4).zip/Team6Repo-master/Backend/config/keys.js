module.exports = {
    mongoURI: "mongodb+srv://Alex:Alex123@authenticchef.xcngx.gcp.mongodb.net/ChefRUs?retryWrites=true&w=majority" ,
  };