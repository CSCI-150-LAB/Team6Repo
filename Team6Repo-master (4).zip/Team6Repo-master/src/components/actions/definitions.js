export const get_errors = "get_errors"; 
export const user_loading = "user_loading"; 
export const set_current_user = "set_current_user"; 
export const set_user_role = "set_user_role"; 
